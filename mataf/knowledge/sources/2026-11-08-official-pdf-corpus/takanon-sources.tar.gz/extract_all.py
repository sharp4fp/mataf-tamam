#!/usr/bin/env python3
"""Extract זקנה coefficient grids from pension תקנון PDFs (bbox-based, RTL-robust)."""
import re, html.parser, subprocess, sys, json, csv, io

NUM = re.compile(r'^-?\d+(\.\d+)?$|^-$|^–$')
YEAR = re.compile(r'^(19[3-9]\d|20[0-2]\d)$')
AGE = re.compile(r'^(6\d|7\d|8\d|90)$')
PCT = re.compile(r'^\d+(\.\d+)?%$')

class WP(html.parser.HTMLParser):
    def __init__(self):
        super().__init__(); self.pages=[]; self.cur=[]; self.w=None
    def handle_starttag(self, tag, attrs):
        if tag=='word':
            d=dict(attrs); self.w={'x0':float(d['xmin']),'y0':float(d['ymin']),'x1':float(d['xmax']),'y1':float(d['ymax']),'t':''}
        elif tag=='page':
            if self.cur: self.pages.append(self.cur)
            self.cur=[]
    def handle_data(self, data):
        if self.w is not None: self.w['t']+=data
    def handle_endtag(self, tag):
        if tag=='word' and self.w is not None:
            self.cur.append(self.w); self.w=None
    def close(self):
        super().close()
        if self.cur: self.pages.append(self.cur); self.cur=[]

def get_pages(pdf, p0, p1):
    out = subprocess.run(['pdftotext','-f',str(p0),'-l',str(p1),'-bbox',pdf,'-'],
                         capture_output=True, text=True).stdout
    p = WP(); p.feed(out); p.close()
    return p.pages

def lines_of(words, ytol=3.0):
    ws = sorted(words, key=lambda w: ((w['y0']+w['y1'])/2, w['x0']))
    lines=[]
    for w in ws:
        yc=(w['y0']+w['y1'])/2
        if lines and abs(lines[-1]['yc']-yc)<=ytol:
            lines[-1]['ws'].append(w)
        else:
            lines.append({'yc':yc,'ws':[w]})
    for ln in lines: ln['ws'].sort(key=lambda w:w['x0'])
    return lines

def norm(t):
    t=t.strip()
    rev=t[::-1]
    return t, rev

def parse_grids(words, page_gender=None):
    """Return list of grids: {gender, years:{x:year}, rows:[(age,{year:val})]}, and pct tables."""
    lines = lines_of(words)
    # gender label positions
    genders=[]
    for ln in lines:
        linecat=''.join(w['t'] for w in ln['ws'])
        for w in ln['ws']:
            t, rev = norm(w['t'])
            if t in ('גברים','גבר','נשים','אישה') or rev in ('גברים','גבר','נשים','אישה'):
                genders.append({'yc':ln['yc'],'x':(w['x0']+w['x1'])/2,'t':GENDER_MAP.get(t) or GENDER_MAP.get(rev)})
                break
        else:
            cat=linecat.replace(' ','')
            if 'םירבג' in cat or 'רבג' in cat:
                genders.append({'yc':ln['yc'],'x':0,'t':'M'})
            elif 'םישנ' in cat or 'השא' in cat or 'השיא' in cat:
                genders.append({'yc':ln['yc'],'x':0,'t':'F'})
    grids=[]; cur=None
    for ln in lines:
        toks=ln['ws']
        years={ (w['x0']+w['x1'])/2: w['t'] for w in toks if YEAR.match(w['t']) }
        if len(years)>=3:
            if cur and cur['rows']: grids.append(cur)
            cur={'years':years,'rows':[],'yc':ln['yc']}
            continue
        if cur:
            nums=[w for w in toks if NUM.match(w['t']) or PCT.match(w['t'])]
            ages=[w for w in toks if AGE.match(w['t'])]
            if len(nums)>=3 and ages:
                age_tok=max(ages,key=lambda w:(w['x0']+w['x1'])/2)
                # year columns sorted by x
                xs=sorted(cur['years'].keys())
                vals={}
                for w in nums:
                    if w is age_tok: continue
                    xc=(w['x0']+w['x1'])/2
                    nx=min(xs,key=lambda x:abs(x-xc))
                    if abs(nx-xc)<15:
                        vals[cur['years'][nx]]=w['t']
                if len(vals)>=3:
                    cur['rows'].append((int(age_tok['t']), vals))
            else:
                if cur['rows']: grids.append(cur); cur=None
    if cur and cur['rows']: grids.append(cur)
    # assign genders by y position (grids below a gender label)
    genders.sort(key=lambda g:g['yc'])
    for g in grids:
        lab=None
        for gl in genders:
            if gl['yc'] < g['yc']+5: lab=gl
        g['gender'] = page_gender or (lab['t'] if lab else None)
    return grids

def parse_adjustments(words):
    """Extract age-gap adjustment tables: lines with a gap int (-15..15) and PCT tokens.
    Returns list of {gap, gender, pct}. Gender by x-proximity to גבר/אישה header tokens."""
    lines = lines_of(words)
    glabels=[]
    for ln in lines:
        for w in ln['ws']:
            t, rev = norm(w['t'])
            if t in ('גבר','אישה') or rev in ('גבר','אישה'):
                glabels.append({'yc':ln['yc'],'x':(w['x0']+w['x1'])/2,'g':GENDER_MAP[t if t in GENDER_MAP else rev]})
        present={g['g'] for g in glabels if g['yc']==ln['yc']}
        if len(present)<2:
            # fragmented tokens: sliding concatenation of adjacent tokens
            ws=ln['ws']
            i=0
            while i < len(ws):
                cat=''; matched=False
                for j in range(i,len(ws)):
                    cat+=ws[j]['t']
                    r=cat[::-1]
                    if r in ('גבר','אישה') or cat in ('גבר','אישה'):
                        g=r if r in ('גבר','אישה') else cat
                        gg=GENDER_MAP[g]
                        if gg not in present:
                            x=(ws[i]['x0']+ws[j]['x1'])/2
                            glabels.append({'yc':ln['yc'],'x':x,'g':gg})
                            present.add(gg)
                        i=j+1; matched=True; break
                if not matched: i+=1
    out=[]
    for ln in lines:
        gaps=[w for w in ln['ws'] if re.match(r'^-?\d{1,2}$', w['t']) and -25<=int(w["t"])<=25]
        pcts=[w for w in ln['ws'] if PCT.match(w['t'])]
        if gaps and pcts:
            gap=int(gaps[0]['t'])
            for pw in pcts:
                xc=(pw['x0']+pw['x1'])/2
                cand=[g for g in glabels if abs(g['yc']-ln['yc'])<650]
                if cand:
                    g=min(cand,key=lambda g:abs(g['x']-xc))
                    out.append({'gap':gap,'gender':g['g'],'pct':float(pw['t'][:-1])})
    return out

# table specs: (company, pdf, [(page, meta)], layout)
SPECS = []
def add(company, pdf, pages_meta, layout, base_note):
    SPECS.append({'company':company,'pdf':pdf,'pages':pages_meta,'layout':layout,'base':base_note})

G_MENORA = lambda pg, sp, gu: (pg, {'spouse':sp,'guarantee':gu})
add('menora','menora-mekifa.pdf',
    [(95,'with_spouse','none'),(96,'with_spouse','120m'),(97,'with_spouse','180m'),(98,'with_spouse','240m'),(99,'with_spouse','until87'),
     (100,'no_spouse','none'),(101,'no_spouse','120m'),(102,'no_spouse','180m'),(103,'no_spouse','240m'),(104,'no_spouse','until87')],
    'two_grids','base: age-gap via adjustment table; fee assumption per תקנון')
add('meitav','meitav-2026-booklet.pdf',
    [(107,'single','none'),(108,'single','none'),(109,'married','none'),(110,'married','none'),
     (111,'single','5y'),(112,'single','5y'),(113,'married','5y'),(114,'married','5y'),
     (115,'no_survivors','10y'),(116,'no_survivors','10y'),(117,'married','10y'),(118,'married','10y'),
     (119,'single','15y'),(120,'single','15y'),(121,'married','15y'),(122,'married','15y'),
     (123,'single','20y'),(124,'single','20y'),(125,'married','20y'),(126,'married','20y')],
    'per_page','base: spouse age-gap 3y, 60% survivor, fee 0.3%')
add('clal','clal-y703-5-2026.pdf',
    [(95,'spouse30','none'),(96,'spouse60','none'),(97,'spouse30','60m'),(98,'spouse60','60m'),
     (99,'spouse30','120m'),(100,'spouse60','120m'),(101,'spouse30','180m'),(102,'spouse60','180m'),
     (103,'spouse30','240m'),(104,'spouse60','240m'),(105,'no_survivors','none'),(106,'no_survivors','60m'),
     (107,'no_survivors','120m'),(108,'no_survivors','180m'),(109,'no_survivors','240m'),
     (110,'spouse100','none'),(111,'spouse100','60m'),(112,'spouse100','120m'),(113,'spouse100','180m'),(114,'spouse100','240m'),
     (115,'with_spouse','until87'),(116,'no_spouse','until87')],
    'two_grids','base: spouse age-gap 3y')
add('harel','harel-6-2025.pdf',
    [(139,'spouse60','none'),(140,'spouse60','60m'),(141,'spouse60','120m'),(143,'spouse60','180m'),
     (144,'spouse100','none'),(145,'no_survivors','none'),(146,'no_survivors','120m'),
     (147,'spouse60','240m'),(149,'no_survivors','240m')],
    'two_grids','base: spouse age-gap 3y; מקדמים משוערכים per תקנון note')
add('migdal','migdal-ishit-062025.pdf',
    [(93,'spouse60','none'),(94,'spouse60','60m_max87'),(95,'spouse60','120m_max87'),(96,'spouse60','180m_max87'),(97,'spouse60','240m_max87'),
     (98,'spouse100','none'),(99,'no_survivors','none'),(100,'no_survivors','60m_max87'),(101,'no_survivors','120m_max87'),
     (102,'no_survivors','180m_max87'),(103,'no_survivors','240m_max87')],
    'two_grids','base: spouse age-gap 3y; guarantee capped at age 87')
add('altshuler','altshuler-010625.pdf',
    [(111,'single','none'),(112,'single','none'),(113,'married','none'),(114,'married','none'),
     (115,'single','5y'),(116,'single','5y'),(117,'married','5y'),(118,'married','5y'),
     (119,'single','10y'),(120,'single','10y'),(121,'married','10y'),(122,'married','10y'),
     (123,'single','15y'),(124,'single','15y'),(125,'married','15y'),(126,'married','15y'),
     (127,'single','20y'),(128,'single','20y'),(129,'married','20y'),(130,'married','20y')],
    'per_page','base: per תקנון')
add('more','more-4-2026.pdf',
    [(102,'single','none'),(103,'married','none'),(104,'single','5y'),(105,'married','5y'),
     (106,'single','10y'),(107,'married','10y'),(108,'single','15y'),(109,'married','15y'),
     (110,'single','20y'),(111,'married','20y')],
    'two_grids','base: per תקנון')
add('infinity','infinity-5-2025.pdf',
    [(99,'with_survivors','none'),(100,'no_survivors','none'),(101,'with_survivors','10y'),(102,'no_survivors','10y'),
     (103,'with_survivors','15y'),(104,'no_survivors','15y'),(105,'with_survivors','20y'),(106,'no_survivors','20y')],
    'two_grids','base: fee 0.5% per תקנון')
add('phoenix','phoenix-1-7-2024.pdf', [], 'custom', 'base: spouse age-gap 3y')

GENDER_MAP = {'גברים':'M','גבר':'M','נשים':'F','אישה':'F','לאלמן':'M','לאלמנה':'F'}

def run():
    out_rows=[]; adj_rows=[]; problems=[]
    # --- custom phoenix pass: pages 128-142, headings + grids in document order.
    # Grids can span page breaks (continuation rows without a repeated year header),
    # so parse grids over combined pages with per-page y-offsets; strip page-number tokens.
    def phx_label(txt):
        t=re.sub(r'[\u202a-\u202e\u200e\u200f]','',txt).replace(' ','')
        if 'זקנה' not in t: return None
        if 'ללאנשויוללאהבטחה' in t: return ('single','none')
        if 'נשויוללאהבטחה' in t: return ('married','none')
        m=re.search(r'הבטחהל-?(\d+)שנים', t)
        if m:
            yrs=m.group(1)[::-1]  # digit order reversed in RTL extraction
            sp='single' if 'ללאנשוי' in t else ('married' if 'נשוי' in t else 'unknown')
            return (sp, str(int(yrs))+'y')
        return None
    OFF=10000
    def combine(pdf, p0, p1):
        allw=[]
        for pi, words in enumerate(get_pages(pdf, p0, p1)):
            for w in words:
                w2=dict(w); w2['y0']+=pi*OFF; w2['y1']+=pi*OFF; w2['_page']=p0+pi
                allw.append(w2)
        return allw
    hw = combine('phoenix-1-7-2024.pdf', 128, 142)
    gw=[]
    for pi, words in enumerate(get_pages('phoenix-1-7-2024.pdf', 129, 142)):
        for w in words:
            w2=dict(w); w2['y0']+=(pi+1)*OFF; w2['y1']+=(pi+1)*OFF
            if re.match(r'^\d{3}$', w2['t']) and w2['y0']%OFF>700: continue
            gw.append(w2)
    events=[]
    for ln in lines_of(hw):
        txt=' '.join(w['t'][::-1] for w in reversed(ln['ws']))
        lab=phx_label(txt)
        if lab and 'נספח' in txt.replace(' ',''):
            events.append(('head',ln['yc'],lab))
    for g in parse_grids(gw):
        events.append(('grid',g['yc'],g))
    events.sort(key=lambda e:e[1])
    cur=('unknown','unknown')
    for kind,yc,payload in events:
        if kind=='head': cur=payload
        else:
            if cur==('unknown','unknown'): continue  # pre-heading commutation grids
            g=payload
            for (age, vals) in g['rows']:
                for yr,v in vals.items():
                    if v in ('-','–','0.00','0.0'): continue
                    try: fv=float(v)
                    except: continue
                    out_rows.append({'company':'phoenix','page':int(yc//OFF)+128,'spouse_scenario':cur[0],'guarantee':cur[1],
                                     'gender':g['gender'],'age':age,'birth_year':yr,'mekadem':fv})
    # adjustments per page, assigned to the table whose heading precedes them
    for pi, words in enumerate(get_pages('phoenix-1-7-2024.pdf', 128, 142)):
        pg=128+pi
        adjs=parse_adjustments(words)
        if not adjs: continue
        lab=cur  # not reliable; recompute: last head before this page top
        heads=[(yc,l) for k,yc,l in events if k=='head' and yc < (pg-128)*OFF+50]
        lab = heads[-1][1] if heads else ('unknown','unknown')
        for a in adjs:
            a.update({'company':'phoenix','page':pg,'spouse_scenario':lab[0],'guarantee':lab[1]})
            adj_rows.append(a)
    # --- standard per-page specs
    for spec in SPECS:
        if spec['layout']=='custom': continue
        comp=spec['company']
        pages = spec['pages']
        p0=min(p for p,_,_ in pages); p1=max(p for p,_,_ in pages)
        pgs = get_pages(spec['pdf'], p0, p1)
        for (pg,sp,gu) in pages:
            idx = pg-p0
            if idx<0 or idx>=len(pgs):
                problems.append((comp,pg,'missing page')); continue
            words=pgs[idx]
            # gender for per_page layout: find gender word on page
            pgender=None
            if spec['layout']=='per_page':
                full=''.join(w['t'] for w in words)
                revfull=full[::-1]
                if 'גברים' in revfull or 'גברים' in full: pgender='M'
                elif 'נשים' in revfull or 'נשים' in full: pgender='F'
                else:
                    for w in words:
                        t, rev = norm(w['t'])
                        if t in ('גברים','נשים','גבר','אישה') or rev in ('גברים','נשים','גבר','אישה'):
                            pgender=GENDER_MAP.get(t) or GENDER_MAP.get(rev); break
            grids = parse_grids(words, page_gender=pgender)
            for a in parse_adjustments(words):
                a.update({'company':comp,'page':pg,'spouse_scenario':sp,'guarantee':gu})
                adj_rows.append(a)
            for g in grids:
                gen = g['gender']
                gen = GENDER_MAP.get(gen, gen)
                if gen not in ('M','F'):
                    # try gender label nearest above within page
                    gen = None
                # filter out commutation tables (values ~ 10-100 range at age 60?) keep all, tag later
                for (age, vals) in g['rows']:
                    for yr,v in vals.items():
                        if v in ('-','–','0.00','0.0'): continue
                        try: fv=float(v)
                        except: continue
                        out_rows.append({'company':comp,'page':pg,'spouse_scenario':sp,'guarantee':gu,
                                         'gender':gen,'age':age,'birth_year':yr,'mekadem':fv})
    with open('grids.csv','w',newline='') as f:
        w=csv.DictWriter(f, fieldnames=['company','page','spouse_scenario','guarantee','gender','age','birth_year','mekadem'])
        w.writeheader()
        for r in sorted(out_rows, key=lambda r:(r['company'],r['page'],str(r['gender']),r['age'],r['birth_year'])):
            w.writerow(r)
    with open('adjustments.csv','w',newline='') as f:
        w=csv.DictWriter(f, fieldnames=['company','page','spouse_scenario','guarantee','gap','gender','pct'])
        w.writeheader()
        for r in sorted(adj_rows, key=lambda r:(r['company'],r['page'],str(r['gender']),r['gap'])):
            w.writerow(r)
    print('---PROBLEMS---', file=sys.stderr)
    for p in problems: print(p, file=sys.stderr)
    # stats
    from collections import Counter
    c=Counter((r['company'],r['page']) for r in out_rows)
    for k in sorted(c): print(k, c[k], file=sys.stderr)

run()
